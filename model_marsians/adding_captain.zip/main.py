from flask import Flask
from model_marsians.data import db_session
from data.users import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/users.db")

    user1 = User()
    user1.name = "Ridley"
    user1.surname = "Scott"
    user1.age = 21
    user1.position = "captain"
    user1.specialty = "research engineer"
    user1.address = "module_1"
    user1.email = "scott_chief@mars.org"

    user2 = User()
    user2.name = "Sergey"
    user2.surname = "Pahomov"
    user2.age = 39
    user2.position = "officer"
    user2.specialty = "cook"
    user2.address = "gaptwachta"
    user2.email = "sweetbread@yandex.ru"

    user3 = User()
    user3.name = "Manfred"
    user3.surname = "Richthofen"
    user3.age = 23
    user3.position = "pilot"
    user3.specialty = "solder"
    user3.address = "grunstrasse3"
    user3.email = "redbaron@gmail.de"

    user4 = User()
    user4.name = "Karl"
    user4.surname = "Marx"
    user4.age = 64
    user4.position = "teacher"
    user4.specialty = "banker"
    user4.address = "westminster7"
    user4.email = "communist_philosopht@gmail.com"

    db_sess = db_session.create_session()
    db_sess.add(user1)
    db_sess.add(user2)
    db_sess.add(user3)
    db_sess.add(user4)
    db_sess.commit()


if __name__ == '__main__':
    main()